<?php
  include 'connection.php';
  $id=$_GET['updateid'];
  $sql="Select * from `root` where id=$id";
  $result=mysqli_query($con,$sql);
  $row=mysqli_fetch_assoc($result);
  $name=$row['name'];
  $email=$row['email'];
  $mobile=$row['mobile'];
  $password=$row['password'];
    
  if(isset($_POST['submit'])){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $mobile=$_POST['mobile'];
    $password=$_POST['password'];

    $sql="update `root` set id='$id',name='$name',email='$email',mobile='$mobile',password='$password' where id=$id";
    $result=mysqli_query($con,$sql); 
      if($result){
       //echo "data updated successfully";
       header('location:display.php');
      }else{
        die(mysqli_error($con));
      }
  }
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Curd Operation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    
  </head>
  <body>
  <style>
      body {
        background-image: url('https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/c5484d98-9c83-4266-883d-4dd0d473186a/d19tmvl-570b72b0-ee55-404d-9b74-48efd9e356e4.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7InBhdGgiOiJcL2ZcL2M1NDg0ZDk4LTljODMtNDI2Ni04ODNkLTRkZDBkNDczMTg2YVwvZDE5dG12bC01NzBiNzJiMC1lZTU1LTQwNGQtOWI3NC00OGVmZDllMzU2ZTQuanBnIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmZpbGUuZG93bmxvYWQiXX0.MZnGEKhSRV3j7MVfYHypHZkUekuWol30YP52niadPoM');
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: cover;
      }
      </style>

    <div class="container my-5">
      <form method="post" action="">
      <div class="mb-3">
        <label style="color:black" >Name</label>
        <input type="text" class="form-control" placeholder="Enter your name" name="name" required
        value=<?php echo $name;?>>
      </div>
      <div class="mb-3">
        <label style="color:black" >Email</label>
        <input type="email" class="form-control" placeholder="Enter your email" name="email" pattern="[^ @]*@[^ @]*" required 
        value=<?php echo $email;?> >
      </div>
      <div class="mb-3">
        <label style="color:black">Mobile</label>
        <input type="tel" class="form-control" placeholder="Enter your Mobile Number" name="mobile" pattern="[0-9]{10}" required
        value=<?php echo $mobile;?>>
      </div>
      <div class="mb-3">
        <!--<label >Password</label>
        <input type="password" id="myInput" class="form-control" placeholder="Enter your Password" name="password" autocomplete="off" required>
        <input type="checkbox" id="showPassword" />
        <label for="showPassword">Show password</label>
      </div>
      <button type="submit" class="btn btn-primary" name="submit">Submit</button>-->
      <label style="color:black">Password</label>
      <input type="password" value="" id="myInput" class="form-control" placeholder="Enter your Password" name="password" 
      autocomplete="off" required value=<?php echo $password;?>>
      <input type="checkbox" onclick="myFunction()">Show Password   <br>
      <button type="submit" class="btn btn-primary" name="submit">Update</button>                                                                                                                                                       
    </div>
    <script>
      function myFunction() {
        var x = document.getElementById("myInput");
        if (x.type === "password") {
          x.type = "text";
        } else {
          x.type = "password";
        }
      }
  </script>
  </body>
</html>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 