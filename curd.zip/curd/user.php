<?php
  include 'connection.php';
  if(isset($_POST['submit'])){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $mobile=$_POST['mobile'];
    $password=$_POST['password'];

    $sql="insert into `root`(name,email,mobile,password)
    values('$name','$email','$mobile','$password')";
    $result=mysqli_query($con,$sql); 
      if($result){
       // echo "data inserted successfully";
      }else{
        die(mysqli_error($con));
      }
  }
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Curd Operation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    
  </head>
  <body>
    <div class="container my-5">
      <form method="post" action="">
      <div class="mb-3">
        <label >Name</label>
        <input type="text" class="form-control" placeholder="Enter your name" name="name" required>
      </div>
      <div class="mb-3">
        <label >Email</label>
        <input type="email" class="form-control" placeholder="Enter your email" name="email" pattern="[^ @]*@[^ @]*" required >
      </div>
      <div class="mb-3">
        <label >Mobile</label>
        <input type="tel" class="form-control" placeholder="Enter your Mobile Number" name="mobile" pattern="[0-9]{10}" required>
      </div>
      <div class="mb-3">
        <!--<label >Password</label>
        <input type="password" id="myInput" class="form-control" placeholder="Enter your Password" name="password" autocomplete="off" required>
        <input type="checkbox" id="showPassword" />
        <label for="showPassword">Show password</label>
      </div>
      <button type="submit" class="btn btn-primary" name="submit">Submit</button>-->
      <label >Password</label>
      <input type="password" value="" id="myInput" class="form-control" placeholder="Enter your Password" name="password" autocomplete="off" required>
      <input type="checkbox" onclick="myFunction()">Show Password   <br>
      <button type="submit" class="btn btn-primary" name="submit">Submit</button>                                                                                                                                                       
    </div>
    <script>
      function myFunction() {
        var x = document.getElementById("myInput");
        if (x.type === "password") {
          x.type = "text";
        } else {
          x.type = "password";
        }
      }
  </script>
  </body>
</html>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 